count_data <- read.csv("spectral_count.csv")
annot_data <- read.csv("sample_annotation.csv")

# Set rownames to first column values
rownames(annot_data)<-annot_data[,1]
annot_data<-annot_data[,-1]
# Ensure first column rownames of dataframes match (only for this dataset)
rownames(annot_data)<-gsub("-",".",rownames(annot_data))

# Import spectral_count as matrix
count_matrix<-as.matrix(count_data)
rownames(count_matrix)<-count_matrix[,1] # first column is protein name
count_matrix<-count_matrix[,-1]
rownames<-rownames(count_matrix)
count_matrix<-apply(count_matrix, 2, as.numeric) # make sure the value is numeric
rownames(count_matrix)<-rownames

# Melt spectral_count
long<-melt(count_matrix, value.name = "LogIntensities", varnames = c('Protein', 'SUBJECT_ORIGINAL'))

# Set SUBJECT = SUBJECT_ORIGINAL
long[,"SUBJECT"] <- as.numeric(long[, "SUBJECT_ORIGINAL"])

# For this dataset, n_RUN = n_SUBJECT as there was a single technical replicate performed
long[,"originalRUN"] <- as.numeric(long[, "SUBJECT_ORIGINAL"])

# Set RUN = originalRUN
long[,"RUN"] <- as.numeric(long[, "originalRUN"])

# Make Sample ID the first column
long<-long[,c(2,1,3:ncol(long))]

# Merge with group from sample_annotation
long<-cbind(long, GROUP_ORIGINAL=annot_data[,"Histological.type"])

# Set GROUP = GROUP ORIGINAl
long[,"GROUP"] <- as.numeric(long[, "GROUP_ORIGINAL"])

# Create SUBJECT_NESTED
long[,"SUBJECT_NESTED"]<-paste(long[,"SUBJECT"], long[, "GROUP"], sep = ".")

# Reorder columns to match example
long<-long[,c("RUN", "Protein", "LogIntensities", "originalRUN", "GROUP", "GROUP_ORIGINAL", "SUBJECT_ORIGINAL", "SUBJECT_NESTED", "SUBJECT")]

# Finally done
save(long, file="formatted_for_MSstats.rda")





